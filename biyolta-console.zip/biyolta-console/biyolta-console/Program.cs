﻿using System;
using System.Diagnostics;
using System.IO.Ports;

namespace biyolta_console
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
                Console.WriteLine("Listing...");
				SerialPort port = new SerialPort("COM1");

				port.BaudRate = 9600;
				port.Parity = Parity.None;
				port.StopBits = StopBits.Two;
				port.DataBits = 8;
				port.Handshake = Handshake.None;
				port.RtsEnable = true;
				port.DataReceived += new SerialDataReceivedEventHandler(DataReceiveHandler);
                Console.WriteLine("Port Opened...");
                port.Open();
                
			}
			catch (Exception e)
			{
				Debug.Print(e.Message);
			}
		}

		private static void DataReceiveHandler(Object sender, SerialDataReceivedEventArgs e)
		{
			SerialPort sp = (SerialPort)sender;
			String indata = sp.ReadExisting();
			Debug.Print("Data Received:");
			Debug.Print(indata);

		}

        private void CalculateWieght(int lineNo,int weightType , double data)
        {
           try
            {

                if (lineNo == 1)
                {
                    // weightTypes Leaves - 1 ,containers - 2
                    if(weightType == 2)
                    {
                        //
                    }
                     // reduce wieght
                }
                else
                {
                    // normal weight
                }


            }
            catch(Exception e)
            {
                Debug.Print(e.Message);
            }
        }
	}
}
