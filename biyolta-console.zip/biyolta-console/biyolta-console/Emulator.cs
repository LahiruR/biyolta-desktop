﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Threading;

namespace biyolta_console
{
	class Emulator
	{

			public void WriteData()
			{

			SerialPort serialPort = new SerialPort("COM1")
			{
				BaudRate = 9600
			};
			serialPort.Open();
			byte[] data = {1, 2, 3, 5, 7, 8, 9};
			serialPort.Write(data, 0, data.Length);	
		}

	}
}
